package com.swapnil.railwaydepartmentmanagement.service;

import com.swapnil.railwaydepartmentmanagement.model.Department;
import com.swapnil.railwaydepartmentmanagement.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    public Department saveDepartment(Department department) {
        return departmentRepository.save(department);
    }

    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }
    public Department updateDepartment(String id, Department updatedDepartment) {

        Department department =
                departmentRepository.findById(id).orElse(null);

        if (department != null) {
            department.setDepartmentName(
                    updatedDepartment.getDepartmentName());

            department.setLocation(
                    updatedDepartment.getLocation());

            return departmentRepository.save(department);
        }

        return null;
    }
    public String deleteDepartment(String id) {

        departmentRepository.deleteById(id);

        return "Department Deleted Successfully";
    }
    public Department getDepartmentById(String id) {
        return departmentRepository.findById(id).orElse(null);
    }
}