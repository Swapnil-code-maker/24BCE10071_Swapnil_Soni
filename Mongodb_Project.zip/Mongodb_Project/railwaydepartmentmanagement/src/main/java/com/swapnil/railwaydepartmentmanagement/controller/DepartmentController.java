/*This class is responsible for taking http request from postman after that it will call to Departmentservice
and give result in postman**/
package com.swapnil.railwaydepartmentmanagement.controller;

import com.swapnil.railwaydepartmentmanagement.model.Department;
import com.swapnil.railwaydepartmentmanagement.service.DepartmentService; // to call service methods
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*; // reuired for @__ annotations are used to create APIs

import java.util.List;

@RestController //This class contains REST APIs so that spring will treat this class as controller class
@RequestMapping("/department")
public class DepartmentController {

    @Autowired // so that spring automatically creates DepartmentService object.
    private DepartmentService departmentService;

    @PostMapping// this API is used to create a new department and store it in mongoDb
    public Department addDepartment(@RequestBody Department department) {
        return departmentService.saveDepartment(department);
    }

    @GetMapping//this API retrieves all department records from mongoDb
    public List<Department> getAllDepartments() {
        return departmentService.getAllDepartments();
    }
    @PutMapping("/{id}")
    public Department updateDepartment(
            @PathVariable String id,
            @RequestBody Department department) {

        return departmentService.updateDepartment(id, department);
    }
    @DeleteMapping("/{id}") //deletes a department from Mongodb
    public String deleteDepartment(@PathVariable String id) {

        return departmentService.deleteDepartment(id);
    }
    @GetMapping("/{id}")
    public Department getDepartmentById(@PathVariable String id) {
        return departmentService.getDepartmentById(id);
    }
}