/** when postman sends a request related to employees then this controller receives it first */
package com.swapnil.railwaydepartmentmanagement.controller;

import com.swapnil.railwaydepartmentmanagement.model.Employee;
import com.swapnil.railwaydepartmentmanagement.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping //so that when API creates a new employee record it stores it in Mongodb
    public Employee addEmployee(@RequestBody Employee employee) {
        return employeeService.saveEmployee(employee);
    }

    @GetMapping//retrieves all employee records from mongodb
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }
    @PutMapping("/{id}")
    public Employee updateEmployee(
            @PathVariable String id,
            @RequestBody Employee employee) {

        return employeeService.updateEmployee(id, employee);
    }
    @DeleteMapping("/{id}")
    public String deleteEmployee(
            @PathVariable String id) {

        return employeeService.deleteEmployee(id);
    }
    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable String id) {
        return employeeService.getEmployeeById(id);
    }
    @GetMapping("/designation/{designation}")
    public List<Employee> getEmployeesByDesignation(
            @PathVariable String designation) {

        return employeeService
                .getEmployeesByDesignation(designation);
    }
    @GetMapping("/department/{departmentId}")
    public List<Employee> getEmployeesByDepartment(
            @PathVariable String departmentId) {

        return employeeService
                .getEmployeesByDepartment(departmentId);
    }
    @PutMapping("/transfer/{employeeId}/{departmentId}")
    public Employee transferEmployee(
            @PathVariable String employeeId,
            @PathVariable String departmentId) {

        return employeeService.transferEmployee(
                employeeId,
                departmentId);
    }
}