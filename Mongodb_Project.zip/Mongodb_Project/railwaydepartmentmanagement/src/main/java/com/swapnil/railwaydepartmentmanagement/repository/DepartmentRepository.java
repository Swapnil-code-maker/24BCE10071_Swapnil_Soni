package com.swapnil.railwaydepartmentmanagement.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.swapnil.railwaydepartmentmanagement.model.Department;

@Repository
public interface DepartmentRepository extends MongoRepository<Department, String> {

}
/*Bridge between Spring Boot and MongoDB that automatically
 provides CRUD operations for Department documents*/