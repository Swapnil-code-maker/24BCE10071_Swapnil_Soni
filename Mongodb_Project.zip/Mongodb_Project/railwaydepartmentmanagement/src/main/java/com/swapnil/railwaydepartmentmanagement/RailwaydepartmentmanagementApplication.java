package com.swapnil.railwaydepartmentmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RailwaydepartmentmanagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(RailwaydepartmentmanagementApplication.class, args);
    }

}
