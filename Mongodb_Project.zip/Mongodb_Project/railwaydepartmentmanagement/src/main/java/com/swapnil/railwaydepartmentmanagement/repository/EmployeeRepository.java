package com.swapnil.railwaydepartmentmanagement.repository;

import com.swapnil.railwaydepartmentmanagement.model.Employee;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface EmployeeRepository
        extends MongoRepository<Employee, String> {

    List<Employee> findByDesignation(String designation);
    List<Employee> findByDepartmentId(String departmentId);
}
/*Spring Data MongoDB supports query generation from method names.
I created custom methods such as findByDesignation() and findByDepartmentId()
to search employees based on business requirements without writing MongoDB queries manually.*/