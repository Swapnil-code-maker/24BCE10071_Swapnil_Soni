package com.swapnil.railwaydepartmentmanagement.service;

import com.swapnil.railwaydepartmentmanagement.model.Department;
import com.swapnil.railwaydepartmentmanagement.model.Employee;
import com.swapnil.railwaydepartmentmanagement.repository.DepartmentRepository;
import com.swapnil.railwaydepartmentmanagement.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    public Employee saveEmployee(Employee employee) {

        String departmentId =
                employee.getDepartment().getId();

        Department department =
                departmentRepository.findById(departmentId)
                        .orElse(null);

        employee.setDepartment(department);

        return employeeRepository.save(employee);
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employee updateEmployee(
            String id,
            Employee updatedEmployee) {

        Employee employee =
                employeeRepository.findById(id)
                        .orElse(null);

        if (employee != null) {

            employee.setEmployeeName(
                    updatedEmployee.getEmployeeName());

            employee.setDesignation(
                    updatedEmployee.getDesignation());

            employee.setSalary(
                    updatedEmployee.getSalary());

            String departmentId =
                    updatedEmployee.getDepartment().getId();

            Department department =
                    departmentRepository.findById(departmentId)
                            .orElse(null);

            employee.setDepartment(department);

            return employeeRepository.save(employee);
        }

        return null;
    }

    public String deleteEmployee(String id) {

        employeeRepository.deleteById(id);

        return "Employee Deleted Successfully";
    }

    public Employee getEmployeeById(String id) {
        return employeeRepository.findById(id).orElse(null);
    }

    public List<Employee> getEmployeesByDesignation(
            String designation) {

        return employeeRepository.findByDesignation(designation);
    }

    public List<Employee> getEmployeesByDepartment(
            String departmentId) {

        return employeeRepository.findByDepartmentId(departmentId);
    }

    public Employee transferEmployee(
            String employeeId,
            String departmentId) {

        Employee employee =
                employeeRepository.findById(employeeId)
                        .orElse(null);

        Department department =
                departmentRepository.findById(departmentId)
                        .orElse(null);

        if (employee != null && department != null) {

            employee.setDepartment(department);

            return employeeRepository.save(employee);
        }

        return null;
    }
}