package com.swapnil.railwaydepartmentmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwaydepartmentmanagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
